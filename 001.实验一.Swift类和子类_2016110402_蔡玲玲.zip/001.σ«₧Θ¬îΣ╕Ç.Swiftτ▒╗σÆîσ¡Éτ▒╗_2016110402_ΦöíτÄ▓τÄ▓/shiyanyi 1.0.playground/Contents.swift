import UIKit


var arrayTest : [Int] = [Int]()
var isPreimNum = true
for item in 2...10000 {
    for j in 2..<item {
        if item % j == 0 {
            isPreimNum = false
            break
        }
    }
    if isPreimNum {
        arrayTest.append(item)
    }
    isPreimNum = true
}
print(arrayTest)
//一
arrayTest.sort(by: {(num1, num2) in
    return num1 > num2
})
print("1.降序输出:")
print(arrayTest)
//二
arrayTest.sort(by: {
    return $0 > $1
})
print("2.降序输出:")
print(arrayTest)
//三
arrayTest.sort(by: {
    $0 > $1
})
print("3.降序输出:")
print(arrayTest)
//四
arrayTest.sort(){
    $0 > $1
}
print("4.降序输出:")
print(arrayTest)
//五
func test(num1: Int, num2: Int) -> Bool {
    return num1 > num2
}
arrayTest.sort(by: test)
print("5.降序输出:")
print(arrayTest)
