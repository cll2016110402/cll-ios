//
//  MyView.swift
//  第五次作业代码
//
//  Created by 蔡玲玲 student on 2018/11/11.
//  Copyright © 2018年 2016110402. All rights reserved.
//

import UIKit

class MyView:UIView{
}
