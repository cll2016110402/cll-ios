//
//  ViewController.swift
//  Exp9
//
//  Created by 蔡玲玲 on 2018/11/07.
//  Copyright © 2018年 2016110402. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func add(_ sender: UIButton) {
        let x = Int(arc4random()) % Int(view.bounds.width)
        let y = Int(arc4random()) % Int(view.bounds.height)
        
        let v = MyView(frame: CGRect(x: x, y: y, width: 50, height: 50))
        v.backgroundColor = UIColor.red
        self.view.insertSubview(v, at:0)
    }
    @IBAction func move(_ sender: UIButton) {
        for v in view.subviews {
            if v is MyView {
                let x = Int(arc4random()) % Int(view.bounds.width)
                let y = Int(arc4random()) % Int(view.bounds.height)
                
                UIView.animate(withDuration: 3, animations: {
                    v.center = CGPoint(x: x, y: y)
                })
            }
        }
    }
    @IBAction func deleteAll(_ sender: UIButton) {
        for v in view.subviews {
            if v is MyView {
                v.removeFromSuperview()
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

