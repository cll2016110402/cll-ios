//
//  Myview.swift
//  Exp9
//
//  Created by 蔡玲玲 on 2018/11/07.
//  Copyright © 2018年 2016110402. All rights reserved.
//

import UIKit

class MyView: UIView {
    
    func setup(){
        //设置阴影
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: -5, height: -5)
        self.layer.shadowOpacity = 0.5
        self.contentMode = .redraw
        
        //pan--移动
        let panGesturer = UIPanGestureRecognizer(target: self, action: #selector(pan(recognizer:)))
        self.addGestureRecognizer(panGesturer);
        
        //pinch--缩放
        let pinchGesturer = UIPinchGestureRecognizer(target: self, action: #selector(pinch(recognizer:)))
        self.addGestureRecognizer(pinchGesturer);
        
        //rotation--缩放
        let rotationGesturer = UIRotationGestureRecognizer(target: self, action: #selector(rotation(recognizer:)))
        self.addGestureRecognizer(rotationGesturer);
        
        
        //tap
        let tapGesturer = UITapGestureRecognizer(target: self, action: #selector(tap(recognizer:)))
        tapGesturer.numberOfTapsRequired = 2
        self.addGestureRecognizer(tapGesturer)
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    //移动
    @objc func pan(recognizer: UIPanGestureRecognizer){
        switch recognizer.state {
        case .began,.changed,.ended:
            let translation = recognizer.translation(in: self)
            
            self.center.x += translation.x
            self.center.y += translation.y
            
            recognizer.setTranslation(CGPoint.zero, in: self)
        default:
            break
        }
    }
    //缩放
    @objc func pinch(recognizer: UIPinchGestureRecognizer){
        switch recognizer.state {
        case .began,.changed,.ended:
            self.bounds = CGRect(x: 0, y: 0, width: self.bounds.width * recognizer.scale, height: self.bounds.height * recognizer.scale)
            recognizer.scale = 1
        default:
            break
        }
    }
    //旋转
    @objc func rotation(recognizer: UIRotationGestureRecognizer){
        switch recognizer.state {
        case .began,.changed:
            //recognizer.rotation 弧度 pi
            self.transform = CGAffineTransform(rotationAngle: recognizer.rotation)
        case .ended:
            UIView.animate(withDuration: 3, animations: {
                self.transform = CGAffineTransform(rotationAngle: 0)
            })
        default:
            break
        }
    }
    
    //旋转
    @objc func tap(recognizer: UIPanGestureRecognizer){
        switch recognizer.state {
        case .ended:
            self.removeFromSuperview()
        default:
            break
        }
    }
}

