import UIKit

var dictionary1 = ["name":"高木又","age":"30"]
var dictionary2 = ["name":"Sam","age":"66"]

let dicarr = [dictionary1,dictionary2].map{
    return $0["name"]!
}
print(dicarr)

//2)
let str = ["Lucy","20","哈哈","80"].filter{
    return Int($0) != nil
}
print(str)
//3）
let str1 = ["I","am","a","gay"].reduce(""){
    return $0 + "," + $1
}
print(str1)
//4）
let num1 = [1,5,7,10,15].reduce((ax:Int.min,in:Int.max,sum:0))
{ r ,i in(Swift.max(r.ax,i),Swift.min(r.in,i),r.sum+i)
}
print(num1.ax,num1.in,num1.sum)
//5)

func fx1(x:Int) -> Int{
    return 1
}
func fx3(x:Double) ->Double{
    return x
}

func fx2() -> Int{
    return 2
}

let f = [fx1,fx2,fx3].filter{
    return $0 is (Int) -> Int
}

//6)
extension Int{
    mutating func sqrt() -> Double{
        let a1:Double = Double(self)
        let a2:Double = a1 * a1
        return a2
    }
}
var x:Int = 2
print(x.sqrt())

//7
func getMaxAndMin<T:Comparable>(arr:T...)->(T,T){
    var max = arr[0]
    var min = arr[1]
    for item in arr{
        if item>max{
            max = item
        }
        if item < min {
            min = item
        }
    }
    return (max, min)
}
print("(0,3,-10,20,11)中最大值和最小值分别为:",getMaxAndMin(arr:0,3,-10,20,11))
print("(3.1,4.9,-2.9,-10.1,1.0)中最大值和最小值分别为:",getMaxAndMin(arr:3.1,4.9,-2.9,-10.1,1.0))
print("(abce,aghj,sakura,zxy)中最大值和最小值分别为:",getMaxAndMin(arr:"abce","aghj","sakura","zxy"))
